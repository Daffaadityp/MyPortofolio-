global.owner = ['62895383138509']  
global.mods = ['62895383138509'] 
global.prems = ['62895383138509']
global.nameowner = 'Dff'
global.numberowner = '62895383138509' 
global.mail = 'daffaadityp@proton.me' 
global.gc = 'https://whatsapp.com/channel/0029VaLkXCT23n3gKZGzF60l'
global.instagram = 'https://instagram.com/daffazuxx'
global.wm = '© D botz MD'
global.wait = '_*Tunggu sedang di proses.. Wait'
global.eror = '_*Server Error*_'
global.stiker_wait = '*⫹⫺ Stiker sedang dibuat...*'
global.packname = '⫹⫺ DFF'
global.author = 'D botz MD'
global.autobio = false // Set true untuk mengaktifkan autobio
global.maxwarn = '2' // Peringatan maksimum
// INJ THUMBNAIL
global.fotomu = 'https://telegra.ph/file/b827651aec401b0def7fa.jpg'
// HIASAN 
global.fsizedoc = '99999999999999'
global.fpagedoc = '999'
//INI WAJIB DI ISI!//
global.btc = 'fbGsQCWu' 
//Daftar terlebih dahulu https://api.botcahx.eu.org

//INI OPTIONAL BOLEH DI ISI BOLEH JUGA ENGGA//
global.lann = '_'
//Daftar https://api.betabotz.eu.org 

global.APIs = {   
  btc: 'https://api.botcahx.eu.org'
}
global.APIKeys = { 
  'https://api.botcahx.eu.org': 'fbGsQCWu' 
}

let fs = require('fs')
let chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})
